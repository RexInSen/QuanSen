# 📐 QuanSen — Quantitative Portfolio Optimizer

**By Amatra Sen · v1.0**

A Modern Portfolio Theory (MPT) based optimizer that computes the efficient frontier, tangency portfolio, and capital market line — with a sleek Streamlit web UI.

---

## 📁 What's in this Folder

```
QuanSen/
│
├── gui_portfolio.py     ← Main web app (Streamlit GUI) — run this!
├── portfolio_tool.py    ← Core optimizer engine (also works standalone)
├── requirements.txt     ← All Python packages needed
└── README.md            ← This guide
```

---

## ✅ Step-by-Step Setup

### Step 1 — Make sure Python is installed

You need **Python 3.9 or higher**.

Check by opening a terminal/command prompt and typing:
```
python --version
```

If you don't have Python, download it from: https://www.python.org/downloads/
> ⚠️ During install on Windows, tick **"Add Python to PATH"**

---

### Step 2 — Open a terminal in the QuanSen folder

**Windows:** Open the folder → click the address bar → type `cmd` → press Enter

**Mac/Linux:** Open Terminal → type `cd ` (with a space) → drag the QuanSen folder into the terminal → press Enter

---

### Step 3 — Install the required packages

Paste this command and press Enter:

```
pip install -r requirements.txt
```

This may take a minute or two. You only need to do this once.

---

### Step 4 — Launch the Web App (Recommended)

```
streamlit run gui_portfolio.py
```

Your browser will open automatically at **http://localhost:8501**

> If the browser doesn't open, copy that address and paste it into Chrome/Firefox manually.

---

## 🖥️ Using the App

Once the app opens in your browser:

1. **Sidebar → Enter tickers** (e.g. `AAPL, MSFT, GOOGL` for US stocks, or `RELIANCE.NS, HDFCBANK.NS` for Indian NSE stocks)
2. **Set the date range** you want to analyze
3. Click **"Load Data"** to fetch prices from Yahoo Finance
4. Then click **"Run Optimization"** to compute portfolios
5. Explore the tabs: Overview, Efficient Frontier, Portfolios, Metrics, Charts, Export

---

## ⚡ Optional: Run the CLI Version (No GUI)

If you prefer the command-line version:

```
python portfolio_tool.py
```

Follow the prompts — it will ask for number of stocks, dates, and let you search by company name.

---

## 🌐 Internet Required

The app downloads live stock data from Yahoo Finance — **an internet connection is needed**.

---

## 🛠️ Troubleshooting

| Problem | Fix |
|---|---|
| `streamlit: command not found` | Try `python -m streamlit run gui_portfolio.py` |
| `pip: command not found` | Try `pip3 install -r requirements.txt` |
| `ModuleNotFoundError` | Re-run `pip install -r requirements.txt` |
| Browser doesn't open | Manually go to http://localhost:8501 |
| No data for a ticker | Double-check the ticker symbol on finance.yahoo.com |

---

## 📦 Packages Used

| Library | Purpose |
|---|---|
| `streamlit` | Web interface |
| `yfinance` | Stock data from Yahoo Finance |
| `cvxpy` | Convex portfolio optimization |
| `numpy / pandas` | Numerical computation |
| `plotly` | Interactive charts |
| `matplotlib / seaborn` | Static charts & heatmaps |
| `scipy` | Mathematical optimization |

---

## 📬 Contact

Made by **Amatra Sen**. Reach out if anything doesn't work!
